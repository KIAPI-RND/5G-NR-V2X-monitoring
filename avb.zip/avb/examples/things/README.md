# Android Things Example
---

This directory contains example source code for an Android Things integration of
lib_avb and lib_avb_atx. The implementation includes rollback index management
and Verified Boot Hash (VBH) computation.
